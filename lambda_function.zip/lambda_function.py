import json
import boto3

s3_client = boto3.client('s3')

def lambda_handler(event, context):
    bucket_name = 'dashboard-2019'
    key = request_path.lstrip('/')
    
    # Fetch the object from S3
    try:
        s3_response = s3_client.get_object(Bucket=bucket_name, Key=key)
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'text/html'},
            'body': s3_response['Body'].read().decode('utf-8')
        }
    except Exception as e:
        return {
            'statusCode': 404,
            'body': json.dumps(f'Error: {str(e)}')
        }
    # try:
    #     # Get bucket and key from ALB event queryStringParameters
    #     bucket_name = event['queryStringParameters']['bucket']
    #     object_key = event['queryStringParameters']['key']
        
    #     # Fetch the file from S3
    #     s3_response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
    #     file_content = s3_response['Body'].read().decode('utf-8')

    #     # Return the file content
    #     return {
    #         'statusCode': 200,
    #         'statusDescription': '200 OK',
    #         'isBase64Encoded': False,
    #         'headers': {
    #             'Content-Type': 'text/plain',
    #         },
    #         'body': file_content
    #     }

    # except Exception as e:
    #     return {
    #         'statusCode': 500,``
    #         'body': json.dumps({
    #             'error': str(e)
    #         })
    #     }